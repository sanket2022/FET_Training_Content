// // /*$('document').ready(()=>{
// //     $('#login').click((e)=>{
// //         var username=$('input[type=email]#email').val();
// //         var pwd=$('input[type=password]#password').val();
// //         fetch(' http://localhost:3000/user')
// //         .then((response)=>response.json())
// //         .then((data)=>{
// //             $.each(data,function(key,value){
// //                       //jquery part
                    
// //                     })
      
// //         });
// //     });
// // });*/
// $('document').ready(()=>{
//     $('#button').click((e)=>{
//         //var username=$('input[type=email]#email').val();
//         //var pwd=$('input[type=password]#password').val();
//        // console.log(username);
//        // console.log(pwd);
//        // var url="C:\Users\rohanpatil\Desktop\Mini-Project-master\Mini-Project-master\minProject\html\paccount.html"
//        /* $.ajax({
//             type:"GET",
//             url:"http://localhost:3000/user",
//             data:{
//                 email:username,
//                 password:pwd
//             },
//             success:function(data)
//             {
//                 if(data === 'Correct'){
//                     alert('login success');
//                 }else{
//                     alert(data)
//                 }
//             }
//         });*/
//         var val1="pallavi";
//         var val2="venkha";
//         var val2="suhas";
//         if(val1 == ($(this.val()))
//             {

//             }
   
//         fetch(' http://localhost:3000/user')
//         .then((response)=>response.json())
//         .then((data)=>{
//             $.each(data,function(key,value){
               
//                         if(username === value.email  && pwd === value.password){
                            
//                             window.location.href=("../html/paccount.html");
//                             return false;
//                         }
                        
//                     })
//            /* for(var i ;i<data.length;i++){
//                 if(username === data[i].email  && pwd === data[i].password){
//                 alert('ss');
//                 }else{
//                     alert('username or password is incorect');
//             }
                
//             }
//         return false;*/
//         });
//     });
// });

// $('document').ready(()=>{
//     $('button').click((c)=>{
        //var a=$(this).attr('value');
        //console.log(c.id);
       function get_id(c){
           var b=c;
           sessionStorage.setItem("did",b)
        // console.log(b);
        //   var doctorId={
        //       ID:b
        //   }
       }
       
       
         //var c=e.value;
      //  console.log(c); 
        
        //var username=$('input[type=email]#email').val();
        //var pwd=$('input[type=password]#password').val();
       // console.log(username);
       // console.log(pwd);
       // var url="C:\Users\rohanpatil\Desktop\Mini-Project-master\Mini-Project-master\minProject\html\paccount.html"
       /* $.ajax({
            type:"GET",
            url:"http://localhost:3000/user",
            data:{
                email:username,
                password:pwd
            },
            success:function(data)
            {
                if(data === 'Correct'){
                    alert('login success');
                }else{
                    alert(data)
                }
            }
        });*/
       // var val1=(this.id);
    // var b=$("#t1 button").attr('value');
    // console.log(b);
    //  var c=$(this).attr('id');
    // var a=$("#t1").attr("value");
  //  var c=$(this).attr('id');
    //console.log(c);
   // e.preventDefault();
        
       
            
   
       /* fetch(' http://localhost:3000/user')
        .then((response)=>response.json())
        .then((data)=>{
            $.each(data,function(key,value){
               
                        if(username === value.email  && pwd === value.password){
                            
                            window.location.href=("../html/paccount.html");
                            return false;
                        }
                        
                    })*/
        
       // });
//     });
// });