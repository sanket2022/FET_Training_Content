// // $(document).ready(function(){
// // //      $("#d").click(function(e){
// // //      $('#myTable tr').each(function(){
// // //           var a="A"
// // //           console.log(a);
// // //          var id=$(this).find("td").eq(2).html();
// // //          console.log(id);
// // //      })
// // //      });

// // });
// $(document).on('click','#approve',function(){
//     var status="approved";
// var pid=$(this).closest('tr').find('.pidd').text();
//          $.post("http://localhost:3000/pallavi"+pid,// <--post user info on json server-->
//     {
//      status:status 
//     },
//     function(data,status){ 
//       alert("Data: " + data + "\nStatus: " + status);
//     });
             
//             //   url:"http://localhost:3000/user"+id,
//             //     type:"POST",
//             //     success:function(data){
                    
                       
//             //     // $("#datatabl #name").append(data[0].name)
//             //     // $("#datatabl #name1").append(data[1].name)
//             //     // $("#datatabl #name2").append(data[2].name)
                      
//                 });
//           //  });
  
// //});
// //})
$(document).on('click','#approve',function(){
    var status="approved";
var pid=$(this).closest('tr').find('.pid').text();
         fetch("http://localhost:3000/user/" + pid,{// <--post user info on json server-->{
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    method: "PATCH",    
 
    // Fields that to be updated are passed
    body: JSON.stringify({
      status:"app"
    })
  })
    .then(function (response) {
 
      // console.log(response);
      return response.json();
    })
    .then(function (data) {
      console.log(data);
    });
    var pname=$(this).closest('tr').find('.pname').text();
    fetch('http://localhost:3000/user')
        .then((response)=>response.json())
        .then((data)=>{
            $.each(data,function(key,value){
               
                        if( pname=== value.first_name){
                             $("#datatabl #name").append(data[0].name)
                            return false;
                        }
                        
                    })
    });
