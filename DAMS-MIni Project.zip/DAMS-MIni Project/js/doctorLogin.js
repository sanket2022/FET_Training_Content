function validate() {
  const emailInput = document.querySelector("#email").value;
  const pwdInput = document.querySelector("#password").value;
  console.log("In function");
  const object = {
    email: emailInput,
    password: pwdInput
  };
  fetch("http://localhost:3000/doctor")
    .then(res => res.json())
    .then(data => {
      data.every(function(doctor) {
        const jemail = JSON.stringify(doctor.email); //mailid in json data
        const jpassword = JSON.stringify(doctor.password); //password in json data
        const iemail = JSON.stringify(object.email); // input mailid
        const ipassword = JSON.stringify(object.password); //input password
        // console.log(iemail +" " + jemail);
        // console.log(ipassword +" " + jpassword);
        if (jemail == iemail && jpassword == ipassword) {
          console.log("Success");
          //alert("Login Successful");
          location.href = "../html/doc1.html";
          return false;
        } else {
          console.log("Failed");
          //alert("Wrong Email or Password");
          location.href = "../html/doctorLogin.html";
          return true;
        }
      });
    })
    .catch(error => console.log("error"));
}
