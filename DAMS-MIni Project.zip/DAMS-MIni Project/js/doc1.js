


$.ajax({
    url: ' http://localhost:3000/pallavi',
    dataType: 'json',
    success: function (data) {
        for (var i = 0; i < data.length; i++) {
            var row = $('<tr><td class="pname">' + data[i].name + '</td><td>' + data[i].stime
                + '</td><td>' + data[i].etime + '</td><td class="pid">' + data[i].id
                + '</td><td>' + data[i].status + "<button id='approve' type='button'class='btn btn-success'>Approve</button> "
                + " <button type='button' class='btn btn-danger' id='d'>Delete</button>" + '</td></tr>');
            $('#myTable').append(row);
        }
    },
    error: function (jqXHR, textStatus, errorThrown) {
        //alert('Error: ' + textStatus + ' - ' + errorThrown);
    }
})