$(document).ready(function() {
  $("#register").click(function(e) {
    // <--Onclick get info of user function-->
    var first_name = $("input[type=text]#first_name").val();
    var last_name = $("input[type=text]#last_name").val();
    // var age=$('input[type=number]#age').val();
    var password = $("input[type=password]#password").val();
    var email = $("input[type=email]#email").val();
    var phoneNumber = $("input[type=tel]#phoneNumber").val();
    e.preventDefault();
    $.post(
      "http://localhost:3000/user", // <--post user info on json server-->
      {
        first_name: first_name,
        last_name: last_name,
        phoneNumber: phoneNumber,
        email: email,
        password: password
      },
      function(data, status) {  
        if(status=="success"){
          //alert("Registration Successful...!",
          $(location).attr('href',"userLogin.html");
        }
      }
    );
  });
  $('#clear').click(function(e){
    document.getElementById('first_name').value='';
    document.getElementById('last_name').value='';
    document.getElementById('email').value='';
    document.getElementById('phoneNumber').value='';
    document.getElementById('password').value='';
  });
});

