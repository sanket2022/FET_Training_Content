$(document).ready(function () {
  $("#app").click(function (e) {
    // <--Onclick get info of user function-->
    var stime = $("input[type=datetime-local]#sstime").val();
    var etime = $("input[type=datetime-local]#eetime").val();
    var name = $("input[type=text]#name").val();
    var a = sessionStorage.getItem("did");
    console.log(a);
    var d1 = "d1";
    var d2 = "d2";
    var d3 = "d3";
    if (d1 == a) {
      console.log(a);
      $.post(
        "http://localhost:3000/pallavi", // <--post user info on json server-->
        {
          name: name,
          stime: stime,
          etime: etime,
        },
        // function (data, status) {
        //   alert("Appointment Booked..!");
        // }
      );
    }
    if (d2 == a) {
      $.post(
        "http://localhost:3000/vekhna", // <--post user info on json server-->
        {
          name: name,
          stime: stime,
          etime: etime,
        },
        // function (data, status) {
        //   alert("Appointment Booked..!");
        // }
      );
    }
    if (d3 == a) {
      $.post(
        "http://localhost:3000/suhas", // <--post user info on json server-->
        {
          name: name,
          stime: stime,
          etime: etime,
        },
        // function (data, status) {
        //   alert("Appointment Booked..!");
        // }
      );
    }
  });
});
