$(document).ready(function() {
  $("#dregister").click(function(e) {
    // <--Onclick get info of user function-->
    var first_name = $("input[type=text]#first_name").val();
    var last_name = $("input[type=text]#last_name").val();
    var password = $("input[type=password]#password").val();
    var email = $("input[type=email]#email").val();
    var speciality = $("input[type=text]#speciality").val();
    var phoneNumber = $("input[type=tel]#phoneNumber").val();
    e.preventDefault();
    $.post(
      "http://localhost:3000/doctor", // <--post doctor info on json server-->
      {
        first_name: first_name,
        last_name: last_name,
        phoneNumber: phoneNumber,
        email: email,
        speciality: speciality,
        password: password
      },
      (data, status) => {
        if (status == "success") {
          //alert("Registration Successful...!",
            $(location).attr('href', "doctorLogin.html");
        }
      }
    );
  });
  $('#clear').click(function(e){
    document.getElementById('first_name').value='';
    document.getElementById('last_name').value='';
    document.getElementById('email').value='';
    document.getElementById('phoneNumber').value='';
    document.getElementById('speciality').value='';
    document.getElementById('password').value='';
  })
});

