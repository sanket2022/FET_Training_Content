 $(document).ready(function(){
   // <-- show Doctor info-->
  $.ajax({
             
              url:"http://localhost:3000/doctor",
                type:"GET",
                success:function(data){
                    
                       
                $("#datatabl #name").append(data[0].name)
                $("#datatabl #name1").append(data[1].name)
                $("#datatabl #name2").append(data[2].name)
                      
                }
            });
  
});
