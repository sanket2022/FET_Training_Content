function logout(){
    //let value = confirm("You really wish to Logout");

    if(true){
        location.href = "../html/index.html";
    }

}